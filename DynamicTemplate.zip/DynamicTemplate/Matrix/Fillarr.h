#pragma once
#include "stdafx.h"

template <typename T1>
void fill(T1 **matrix, int height, int width, T1 ran);