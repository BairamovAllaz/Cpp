#pragma once
#include "stdafx.h"

template <typename T1> void print(T1 **matrix, int height, int width);