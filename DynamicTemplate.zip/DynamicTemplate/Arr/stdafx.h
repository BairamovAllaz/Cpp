#pragma once
#include <iostream>
#include <ctime>
using namespace std;
using std::cout;
using std::endl;
using std::cin;