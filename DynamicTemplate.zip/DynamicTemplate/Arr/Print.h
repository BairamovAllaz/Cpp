#pragma once
#include "stdafx.h"

template <typename T1> void PrintArray(T1 *arr, int *size);
void printString(char *string);